from os.path import exists
from glob import glob
from aiohttp import request
from discord import Intents, Activity, ActivityType
from discord.errors import Forbidden
from discord.ext.commands import Bot as BotBase
from discord.ext.commands import has_permissions
from discord.ext.commands import (CommandNotFound, BadArgument, MissingRequiredArgument, CommandOnCooldown, MissingPermissions)
from blaster import Config
from asyncio import sleep

COGS_PATH = 'blaster.extensions.'
EXTENSIONS_PATH = 'blaster/extensions/'
COGS = [path.split("\\")[-1][:-3] for path in glob(f"{EXTENSIONS_PATH}*.py")]

bot = BotBase(command_prefix=Config.PREFIX, intents=Intents.all())


class LoadCogs():
    if Config.LOAD_COGS_ON_START == 'True':
        print('Running Cogs...')
        
        for cog in COGS:
            if EXTENSIONS_PATH in cog:
                cog = cog.replace(EXTENSIONS_PATH, '')

            try:
                bot.load_extension(f'{COGS_PATH}{cog}')
                print(f' - "{cog}" Cog Loaded Successfully')

            except Exception as e:
                print(f' - "{cog}" Cog Not loaded: {e}')
            
        print(f'Cogs Loaded Successfully')



async def status_update():
    await bot.change_presence(activity=Activity(type=ActivityType.watching, name='Discord'))
         

@bot.event
async def on_ready():
    LoadCogs()
    print('Bot is up and ready!')


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, BadArgument):
        pass

    elif isinstance(error, MissingRequiredArgument):
        await ctx.send('***Warning***: [001] One or more required arguments are missing.')

    elif isinstance(error, MissingPermissions):
        await ctx.send('***Warning***: [002] Insufficient permissions to perform that task')
        
    elif isinstance(error, CommandNotFound):
        await ctx.send('***Warning***: [003] Command not found!')

    elif isinstance(error, CommandOnCooldown):
        await ctx.send(f"***Warning***: [004] You're doing that too quickly, try again in {error.retry_after:,.2f}s.")

    elif hasattr(error, 'original'):
        if isinstance(error.original, Forbidden):
            await ctx.send('***Warning***: [005] I do not have permission to do that.')

        else:
            raise error.original

    else:
        raise error
 
 
@bot.command(name='load')
@has_permissions(administrator=True)
async def load(ctx, extension):
    if ctx.channel.id != Config.BOT_COMMAND_CHANNEL_ID:
        return

    if extension == 'all':
        await ctx.send('Loading Cogs...')
        
        for cog in COGS:
            if EXTENSIONS_PATH in cog:
                cog = cog.replace(EXTENSIONS_PATH, '')
    
            try:
                bot.load_extension(f'{COGS_PATH}{cog}')
                await ctx.send(f' - "{cog}" Cog Loaded Successfully')
                
            except Exception as e:
                await ctx.send(f' - "{cog}" Cog Not loaded: {e}')
            
        await ctx.send(f'Cogs task completed Successfully')
        
        return

    if exists(f'{EXTENSIONS_PATH}{extension}.py'):
        try:
            bot.load_extension(f'{COGS_PATH}{extension}')
            await ctx.send(f'Loaded {extension} Successfully!')
        except:
            await ctx.send(f'{extension} is already loaded!')
        
    else:
        await ctx.send(f'Cog not found!')
    

@bot.command(name='unload')
@has_permissions(administrator=True)
async def unload(ctx, extension):
    if ctx.channel.id != Config.BOT_COMMAND_CHANNEL_ID:
        return
    
    if extension == 'all':
        await ctx.send('Unloading Cogs...')
        
        for cog in COGS:
            if EXTENSIONS_PATH in cog:
                cog = cog.replace(EXTENSIONS_PATH, '')
    
            try:
                bot.unload_extension(f'{COGS_PATH}{cog}')
                await ctx.send(f' - "{cog}" Cog Unoaded Successfully')
                
            except Exception as e:
                await ctx.send(f' - "{cog}" Cog Not unloaded: {e}')
            
        await ctx.send(f'Cogs task completed Successfully')
        
        return
    
    if exists(f'{EXTENSIONS_PATH}{extension}.py'):
        try:
            bot.unload_extension(f'{COGS_PATH}{extension}')
            await ctx.send(f'Unloaded {extension} Successfully!')
        except:
            await ctx.send(f'{extension} is already unloaded!')
        
    else:
        await ctx.send(f'Cog not found!')
    
    
@bot.command(name='reload')
@has_permissions(administrator=True)
async def reload(ctx, extension):
    if ctx.channel.id != Config.BOT_COMMAND_CHANNEL_ID:
        return
    
    if extension == 'all':
        await ctx.send('Reloading Cogs...')
        
        for cog in COGS:
            if EXTENSIONS_PATH in cog:
                cog = cog.replace(EXTENSIONS_PATH, '')
    
            try:
                bot.reload_extension(f'{COGS_PATH}{cog}')
                await ctx.send(f' - "{cog}" Cog Reloaded Successfully')
                
            except Exception as e:
                await ctx.send(f' - "{cog}" Cog Not reloaded: {e}')
            
        await ctx.send(f'Cogs task completed Successfully')
            
        return
    
    if exists(f'{EXTENSIONS_PATH}{extension}.py'):
        bot.reload_extension(f'{COGS_PATH}{extension}')
        await ctx.send(f'Reloaded {extension} Successfully!')
        
    else:
        await ctx.send(f'Cog not found!')


bot.loop.create_task(status_update()) 
bot.run(Config.TOKEN)

